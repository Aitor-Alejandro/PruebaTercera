CREATE SCHEMA `bdinventario` ;
CREATE TABLE `bdinventario`.`productos` (
  `idproductos` BIGINT(1) NOT NULL,
  `nombre` VARCHAR(45) NOT NULL,
  `categoria` VARCHAR(45) NULL,
  `precio` DOUBLE NOT NULL,
  `stock` INT NOT NULL,
  PRIMARY KEY (`idproductos`));
INSERT INTO `bdinventario`.`productos` (`idproductos`, `nombre`, `categoria`, `precio`, `stock`) VALUES ('1', 'patatas', 'tuberculo', '4.5', '30');
INSERT INTO `bdinventario`.`productos` (`idproductos`, `nombre`, `categoria`, `precio`, `stock`) VALUES ('2', 'pimiento', 'verdura', '4', '25');
INSERT INTO `bdinventario`.`productos` (`idproductos`, `nombre`, `precio`, `stock`) VALUES ('3', 'zanahoria', '3.4', '20');