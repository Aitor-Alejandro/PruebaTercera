package com.curso.model;

/**
 * Conjunto de categorias a las que podrá pertenecer un producto
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 24/12/2024
 *
 */
public enum Categoria {
	tuberculo,
	verdura,
	dulce;
}
