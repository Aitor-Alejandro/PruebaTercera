package com.curso.model;

/**
 * Clase Producto
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 23/12/2024
 *
 */
public class Producto {
	private long id;
	private String nombre;
	private Categoria cat;
	private double precio;
	private int stock;
	
	/**
	 * Constructor por defecto de la clase Producto
	 */
	public Producto() {
		super();
	}
	
	/**
	 * Constructor de Producto con primary-key para la base de datos
	 * @param id La primary-key del producto
	 */
	public Producto(long id) {
		super();
		this.id = id;
	}
	
	/**
	 * Constructor de clase que inicializa todos los valores
	 * @param id primary-key del producto
	 * @param nombre nombre del producto
	 * @param cat categoria a la que pertenece el preducto, del tipo Enum Categoria
	 * @param precio precio del producto
	 * @param stock cantidad disponible del producto
	 */
	public Producto(long id, String nombre, Categoria cat, double precio, int stock) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.cat = cat;
		this.precio = precio;
		this.stock = stock;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Categoria getCat() {
		return cat;
	}

	public void setCat(Categoria cat) {
		this.cat = cat;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	
}
