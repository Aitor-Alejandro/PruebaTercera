package com.curso.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FrontController
 * Deriva las peticiones de la pestaña de inicio hacia
 * el componente correspondiente para su atención
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 24/12/2024
 */
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option =  request.getParameter("option");
		
		String urlVista="/";
		
		long id;
		
		switch(option) {
		case "alta":
			urlVista="ServletAlta";
			break;
		case "list":
			urlVista="ServletListado";
			break;
		case "buscar":
			urlVista="ServletBusqueda";
			break;
		case "edit":
			id = Long.parseLong(request.getParameter("id")) ;
			urlVista="ServletEdit?id=" + id;
			break;
		case "borrar":
			id = Long.parseLong(request.getParameter("id"));
			urlVista = "ServletBorrar?id=" + id;
			break;
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(urlVista);
		dispatcher.forward(request, response);
	}

}
