package com.curso.conn;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Clase para obtener la conexcion establecida por DataSource
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 24/12/2024
 *
 */
public class DataSourceConn {
	private static DataSource ds;
	
	/**
	 * Inicializa un datasource unico para
	 * todo el funcionamiento de la aplicacion
	 */
	static {
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/MiDataSource");
		}catch(NamingException e) {
			e.printStackTrace();
		}
	}
	
	
	public static Connection getConn() throws SQLException{
		return ds.getConnection();
	}
}
