package com.curso.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.curso.conn.DataSourceConn;
import com.curso.model.Categoria;
import com.curso.model.Producto;

/**
 * Clase que implementa el patron DAO para las operaciones CRUD de los productos
 * de la base de datos
 * 
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 24/12/2024
 *
 */
public class ProductoDao implements IProducto {
	private static Connection conn;
	String allQuery;
	String searchQueryNombre;
	String searchQueryCategoria;
	String findByIdQuery;
	String insertQuery;
	String insertQueryNoCat;
	String updateQuery;
	String deleteQuery;

	static {
		try {
			conn = DataSourceConn.getConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ProductoDao() {
		allQuery = "SELECT * FROM productos";
		searchQueryNombre = "SELECT * FROM productos WHERE nombre = ?";
		searchQueryCategoria = "SELECT * FROM productos WHERE categoria = ?";
		findByIdQuery = "SELECT * FROM productos WHERE idproductos = ?";
		insertQuery = "INSERT INTO productos VALUES (?,?,?,?,?)";
		insertQueryNoCat = "INSERT INTO productos (idproductos, nombre, precio, stock) VALUES (?,?,?,?)";
		updateQuery = "UPDATE productos SET nombre=?,categoria=?,precio=?,stock=? WHERE idproductos=?";
		deleteQuery = "DELETE FROM productos WHERE idproductos=?";
	}

	@Override
	public List<Producto> getAll() {
		List<Producto> productos = null;
		String categoria;
		Optional<Categoria> optCat;
		if (conn != null) {
			try (Statement statement = conn.createStatement(); ResultSet rs = statement.executeQuery(allQuery);) {
				if (rs.isBeforeFirst()) {
					productos = new ArrayList<>();
				}
				while (rs.next()) {
					categoria = rs.getString("categoria");
					optCat = Optional.ofNullable(categoria != null ? Categoria.valueOf(categoria) : null);
					productos.add(new Producto(rs.getLong("idproductos"), rs.getString("nombre"), optCat.orElse(null),
							rs.getDouble("precio"), rs.getInt("stock")));
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return productos;
	}

	@Override
	public List<Producto> searchNombre(String search) {
		List<Producto> productos = null;
		String categoria;
		Optional<Categoria> optCat;
		if (conn != null) {
			try (PreparedStatement prepStatement = conn.prepareStatement(searchQueryNombre);) {
				prepStatement.setString(1, search);
				ResultSet rs = prepStatement.executeQuery();
				if (rs.isBeforeFirst()) {
					productos = new ArrayList<>();
				}
				while (rs.next()) {
					categoria = rs.getString("categoria");
					optCat = Optional.ofNullable(categoria != null ? Categoria.valueOf(categoria) : null);
					productos.add(new Producto(rs.getLong("idproductos"), rs.getString("nombre"), optCat.orElse(null),
							rs.getDouble("precio"), rs.getInt("stock")));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return productos;
	}

	@Override
	public List<Producto> searchCategoria(String search) {
		List<Producto> productos = null;
		String categoria;
		Optional<Categoria> optCat;
		if (conn != null) {
			try (PreparedStatement prepStatement = conn.prepareStatement(searchQueryCategoria);) {
				prepStatement.setString(1, search);
				ResultSet rs = prepStatement.executeQuery();
				if (rs.isBeforeFirst()) {
					productos = new ArrayList<>();
				}
				while (rs.next()) {
					categoria = rs.getString("categoria");
					optCat = Optional.ofNullable(categoria != null ? Categoria.valueOf(categoria) : null);
					productos.add(new Producto(rs.getLong("idproductos"), rs.getString("nombre"), optCat.orElse(null),
							rs.getDouble("precio"), rs.getInt("stock")));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return productos;
	}

	@Override
	public Producto findById(long id) {
		Producto prod = null;
		String categoria;
		Optional<Categoria> optCat;
		if (conn != null) {
			try (PreparedStatement prepStatement = conn.prepareStatement(findByIdQuery);) {
				prepStatement.setLong(1, id);
				ResultSet rs = prepStatement.executeQuery();
				if (rs.isBeforeFirst()) {
					prod = new Producto();
				}
				while (rs.next()) {
					categoria = rs.getString("categoria");
					optCat = Optional.ofNullable(categoria != null ? Categoria.valueOf(categoria) : null);
					prod.setId(rs.getLong("idproductos"));
					prod.setNombre(rs.getString("nombre"));
					prod.setCat(optCat.orElse(null));
					prod.setPrecio(rs.getDouble("precio"));
					prod.setStock(rs.getInt("stock"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return prod;
	}

	@Override
	public void crearProducto(Producto p) {
		if (conn != null) {
			try (PreparedStatement prepState = conn.prepareStatement(findByIdQuery);) {
				prepState.setLong(1, p.getId());
				ResultSet rs = prepState.executeQuery();
				if (rs.isBeforeFirst()) {
					throw new IllegalArgumentException("El elemento con id " + p.getId() + " ya existe");
				}
				if (p.getCat() != null) {
					try (PreparedStatement prepStateInsert = conn.prepareStatement(insertQuery);) {
						prepStateInsert.setLong(1, p.getId());
						prepStateInsert.setString(2, p.getNombre());
						prepStateInsert.setString(3, p.getCat().name());
						prepStateInsert.setDouble(4, p.getPrecio());
						prepStateInsert.setInt(5, p.getStock());
						prepStateInsert.executeUpdate();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}else {
					try(PreparedStatement prepStateInsertNoCat = conn.prepareStatement(insertQueryNoCat);
							){
						prepStateInsertNoCat.setLong(1, p.getId());
						prepStateInsertNoCat.setString(2, p.getNombre());
						prepStateInsertNoCat.setDouble(3, p.getPrecio());
						prepStateInsertNoCat.setInt(4, p.getStock());
						prepStateInsertNoCat.executeUpdate();
					}catch(SQLException e) {
						e.printStackTrace();
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Producto editProducto(Producto p) {
		Producto prod = null;
		if (conn!=null) {
			try(PreparedStatement prepState = conn.prepareStatement(findByIdQuery);
					){
				prepState.setLong(1, p.getId());
				ResultSet rs = prepState.executeQuery();
				if (!rs.isBeforeFirst()) {
					throw new IllegalArgumentException("No existe ningun elemento con id: " + p.getId() + " para editar");
				}
				try (PreparedStatement prepEdit = conn.prepareStatement(updateQuery);
						){
					prepEdit.setString(1, p.getNombre());
					if (p.getCat() != null) {
						prepEdit.setString(2, p.getCat().name());
					}else {
						prepEdit.setNull(2, Types.VARCHAR);
					}
					prepEdit.setDouble(3, p.getPrecio());
					prepEdit.setInt(4, p.getStock());
					prepEdit.setLong(5, p.getId());
					prepEdit.executeUpdate();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return prod;
	}

	@Override
	public List<Producto> deleteProducto(long id) {
		List<Producto> listP = null;
		String categoria;
		Optional<Categoria> optCat;
		if (conn != null) {
			try(PreparedStatement prepState = conn.prepareStatement(findByIdQuery);
					){
				prepState.setLong(1, id);
				ResultSet rs = prepState.executeQuery();
				if (!rs.isBeforeFirst()) {
					throw new IllegalArgumentException("No existe un elemento con id: " + id + " para su borrado");
				}
				try(PreparedStatement deletionState = conn.prepareStatement(deleteQuery);
						){
					deletionState.setLong(1, id);
					deletionState.executeUpdate();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
			try (Statement state = conn.createStatement();
					ResultSet rs = state.executeQuery(allQuery);
					){
				if (rs.isBeforeFirst()) {
					listP = new ArrayList<>();
				}
				while(rs.next()) {
					categoria = rs.getString("categoria");
					optCat = Optional.ofNullable(categoria != null ? Categoria.valueOf(categoria) : null);
					listP.add(new Producto(rs.getLong("idproductos"), rs.getString("nombre"), optCat.orElse(null),
							rs.getDouble("precio"), rs.getInt("stock")));
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return listP;
	}
}
