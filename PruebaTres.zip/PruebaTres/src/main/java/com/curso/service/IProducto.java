package com.curso.service;

import java.util.List;

import com.curso.model.Producto;

public interface IProducto {
	List<Producto> getAll();
	List<Producto> searchNombre(String search);
	List<Producto> searchCategoria(String search);
	Producto findById(long id);
	void crearProducto(Producto p);
	Producto editProducto(Producto p);
	List<Producto> deleteProducto(long id);
}
