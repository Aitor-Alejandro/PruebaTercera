package com.curso.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.curso.model.Producto;
import com.curso.service.ProductoDao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletBusqueda
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 25/12/2024
 */
public class ServletBusqueda extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dis = request.getRequestDispatcher("busqueda.html");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String tipoBusqueda = request.getParameter("formularioType");
		ProductoDao pDao = new ProductoDao();
		
		switch(tipoBusqueda) {
		case "busquedaText":
		{
			String filtroBusq = request.getParameter("filtroBusq");
			if (filtroBusq.equals("nombre")) {
				String busqNombre = request.getParameter("busqueda");
				List<Producto> listP = pDao.searchNombre(busqNombre);
				
				if (listP != null) {
				request.setAttribute("listProducto", listP);
				RequestDispatcher dis = request.getRequestDispatcher("listado.jsp");
				dis.forward(request, response);
				}else {
					request.setAttribute("tipoBusqueda", "nombre");
					request.setAttribute("valorBusqueda", busqNombre);
					
					RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.jsp");
					dis.forward(request, response);
				}
			}else if(filtroBusq.equals("categoria")) {
				String busqCat = request.getParameter("busqueda");
				List<Producto> listP = pDao.searchCategoria(busqCat);
				
				if (listP != null) {
					request.setAttribute("listProducto", listP);
					RequestDispatcher dis = request.getRequestDispatcher("listado.jsp");
					dis.forward(request, response);
				}else {
					request.setAttribute("tipoBusqueda", "categoria");
					request.setAttribute("valorBusqueda", busqCat);
					
					RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.jsp");
					dis.forward(request, response);
				}
			}
			break;
		}
		case "busquedaId":
		{
			long id = Long.parseLong(request.getParameter("busqueda"));
			Producto p = pDao.findById(id);
			List<Producto>listP = new ArrayList<>();
			if (p != null) {
				listP.add(p);
				request.setAttribute("listProducto", listP);
				RequestDispatcher dis = request.getRequestDispatcher("listado.jsp");
				dis.forward(request, response);
			}else {
				request.setAttribute("tipoBusqueda", "id");
				request.setAttribute("valorBusqueda", Long.toString(id));
				
				RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.jsp");
				dis.forward(request, response);
			}
			
			break;
		}
		default:
			response.getWriter().append("Hubo un fallo");
			break;
		}
	}

}
