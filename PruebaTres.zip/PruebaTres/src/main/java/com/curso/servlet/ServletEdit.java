package com.curso.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.curso.model.Categoria;
import com.curso.model.Producto;
import com.curso.service.ProductoDao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletEdit
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 25/12/2024
 */
public class ServletEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long id = Long.parseLong(request.getParameter("id"));
		ProductoDao pDao = new ProductoDao();
		
		Producto p = pDao.findById(id);
		if (p!= null) {
			request.setAttribute("producto", p);
			
			List<Producto> listP = new ArrayList<>();
			listP.add(p);
			
			RequestDispatcher dis = request.getRequestDispatcher("editProd.jsp");
			dis.forward(request, response);
		}else {
			request.setAttribute("tipoBusqueda", "id");
			request.setAttribute("valorBusqueda", id);
			
			RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.jsp");
			dis.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductoDao pDao = new ProductoDao();
		
		long id = Long.parseLong(request.getParameter("id"));
		String nombre = request.getParameter("nombre");
		String cat = request.getParameter("categoria");
		double precio = Double.parseDouble(request.getParameter("precio"));
		int stock = Integer.parseInt(request.getParameter("stock"));
		
		Producto p;
		
		if(cat.isEmpty()) {
			p = new Producto(id, nombre, null, precio, stock);
		}else {
			p = new Producto(id, nombre, Categoria.valueOf(cat), precio, stock);
		}
		
		try {
			pDao.editProducto(p);
			RequestDispatcher dis = request.getRequestDispatcher("index.html");
			dis.forward(request, response);
		}catch(IllegalArgumentException e) {
			e.printStackTrace();
			
			request.setAttribute("tipoBusqueda", "id");
			request.setAttribute("valorBusqueda", id);
			
			RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.jsp");
			dis.forward(request, response);
			
		}
	}

}
