package com.curso.servlet;

import java.io.IOException;
import java.util.List;

import com.curso.model.Producto;
import com.curso.service.ProductoDao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletBorrar
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 25/12/2024
 */
public class ServletBorrar extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long id = Long.parseLong(request.getParameter("id"));
		ProductoDao pDao = new ProductoDao();
		Producto p;
		p = pDao.findById(id);
		
		if (p == null) {
			request.setAttribute("tipoBusqueda", "id");
			request.setAttribute("valorBusqueda", id);
			
			RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.html");
			dis.forward(request, response);
		}
		
		request.setAttribute("producto", p);
		
		RequestDispatcher dis = request.getRequestDispatcher("borrado.jsp");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long id = Long.parseLong(request.getParameter("id"));
		ProductoDao pDao = new ProductoDao();
		List<Producto> listP;
		try {
			listP = pDao.deleteProducto(id);
			if (listP!= null) {
				request.setAttribute("listProducto", listP);
				
				RequestDispatcher dis = request.getRequestDispatcher("listado.jsp");
				dis.forward(request, response);
			}else {
				RequestDispatcher dis = request.getRequestDispatcher("listaVacia.html");
				dis.forward(request, response);
			}
		}catch(IllegalArgumentException e) {
			e.printStackTrace();
			
			RequestDispatcher dis = request.getRequestDispatcher("falloBusqueda.html");
			dis.forward(request, response);
		}
	}

}
