package com.curso.servlet;

import java.io.IOException;
import java.util.List;

import com.curso.model.Categoria;
import com.curso.model.Producto;
import com.curso.service.ProductoDao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletAlta
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 25/12/2025
 */
public class ServletAlta extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dis = request.getRequestDispatcher("alta.html");
		dis.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductoDao pDao = new ProductoDao();
		
		long id = Long.parseLong(request.getParameter("id"));
		String nombre = request.getParameter("nombre");
		Double precio = Double.parseDouble(request.getParameter("precio"));
		int stock = Integer.parseInt(request.getParameter("stock"));
		
		Producto p = null;
		if(request.getParameter("categoria").equals("")) {
			p = new Producto(id, nombre, null, precio, stock);
		}else {	
			p = new Producto (id, nombre, Categoria.valueOf(request.getParameter("categoria")), precio, stock);
		}
		
		try {
			pDao.crearProducto(p);
		}catch(IllegalArgumentException e) {
			e.printStackTrace();
			RequestDispatcher dis = request.getRequestDispatcher("alta.html");
			dis.forward(request, response);
		}
		List<Producto> listP = pDao.getAll();
		request.setAttribute("listProducto", listP);
		RequestDispatcher dis = request.getRequestDispatcher("listado.jsp");
		dis.forward(request, response);
	}

}
