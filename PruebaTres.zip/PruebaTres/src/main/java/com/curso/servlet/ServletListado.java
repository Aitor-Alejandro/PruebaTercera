package com.curso.servlet;

import java.io.IOException;
import java.util.List;

import com.curso.model.Producto;
import com.curso.service.ProductoDao;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletListado
 * @author Aitor Alejandro Martinez Cedillo \ Viewnext
 * @version 1.0 25/12/2024
 */
public class ServletListado extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductoDao pDao = new ProductoDao();
		
		List<Producto> lista = pDao.getAll();
		if (lista != null) {
			request.setAttribute("listProducto", lista);
			RequestDispatcher dispatch = request.getRequestDispatcher("listado.jsp");
			dispatch.forward(request, response);
		}else {
			RequestDispatcher dispatch = request.getRequestDispatcher("listaVacia.html");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
